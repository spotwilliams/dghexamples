<?php
header('OTRA-COSA-QUE-NO-SEA-HTTP: JAJAJAJA OMG!', false, 404);
//header('WWW-Authenticate: NTLM', false);
echo 'Groso!';

 ?>
