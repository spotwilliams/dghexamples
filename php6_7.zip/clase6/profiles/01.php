<?php

echo 'Admin!';

?>
