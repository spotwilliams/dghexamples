<?php
header('USER-ESPERADO: empty');
echo 'GUEST!';

?>
