<?php
$hobbies = [ 0=> 'pescar', 'nadar', 'futbol', 'videogamer'];
$usuario = $name = $pais = '';
  if($_POST){
    var_dump($_POST);
    $usuario = $_POST['usuario'];
    $hobbisSeleccionados = $_POST['hobbies'];
  }


  ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1>Regitro de Usuario</h1>
    <form class="" action="" method="post">
      <div class="">
        <label for="">
          Usuario:
          <input type="text" name="usuario" value="<?= $usuario ?>">
        </label>
      </div>

      <div class="">
        <label for="">Hobbies</label>

        <?php foreach ($hobbies as $hobby): ?>
          <input type="checkbox" name="hobbies[]"  value="<?= $hobby ?>"><?= $hobby ?>
        <?php endforeach; ?>

      </div>

      <div class="">
        <label for="">
          Password:
          <input type="password" name="password" value="">
        </label>
      </div>

      <div class="">
        <button type="submit" >Enviar</button>
      </div>

    </form>

  </body>
</html>
