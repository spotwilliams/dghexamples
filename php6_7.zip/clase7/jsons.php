<?php

$auto = '{"Marca":"Ford","Color":"Negro"}';

var_dump(json_decode($auto, true));
?>
