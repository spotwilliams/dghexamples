import React from 'react';

const Error404 = () => (
  <div>Oops... No encontramos la url</div>
)

export default Error404
