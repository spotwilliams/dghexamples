import React, {Component} from 'react';

const HeaderPeliculas = () => (
  <div>
    <h1>Películas</h1>
    <p>Algun texto quetenga que ver con películas</p>
  </div>
)

export default HeaderPeliculas
