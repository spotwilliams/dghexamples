import React from 'react';

const ModalFooter = ({ children }) => (
  <div className="modal-footer">
    {children}
  </div>
)

export default ModalFooter
