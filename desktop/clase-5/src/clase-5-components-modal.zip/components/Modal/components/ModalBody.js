import React from 'react';

const ModalBody = ({ children }) => (
  <div className="modal-body">
    {children}
  </div>
)

export default ModalBody
